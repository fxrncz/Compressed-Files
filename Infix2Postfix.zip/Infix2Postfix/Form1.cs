﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Infix2Postfix
{
    public partial class Form1 : Form
    {

        public List<char> operandStack;
        public Stack<char> operatorStack;
        List<char> origStack = new List<char>();
        Dictionary<char, int> sortedStack = new Dictionary<char, int>();    

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string output = InfixToPostfix(textBox1.Text);
                textBox2.Text = $"{output} = {EvaluatePostfix(output)}";
            }
            catch (Exception ex)
            {
                textBox2.Text = ex.Message;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string output = InfixToPrefix(textBox1.Text);
                textBox2.Text = output;
            }
            catch (Exception ex)
            {
                textBox2.Text = ex.Message;
            }
        }

        private string InfixToPostfix(string source)
        {
            string output = "";
            operatorStack = new Stack<char>();
            int i = 0;

            while (i < source.Length)
            {
                if (char.IsDigit(source[i]))
                {
                    
                    while (i < source.Length && char.IsDigit(source[i]))
                    {
                        output += source[i];
                        i++;
                    }
                    output += " ";
                    continue;
                }
                else if (source[i] == '(')
                {
                    operatorStack.Push(source[i]);
                }
                else if (source[i] == ')')
                {
                    while (operatorStack.Peek() != '(')
                    {
                        output += operatorStack.Pop() + " ";
                    }
                    operatorStack.Pop(); 
                }
                else
                {
                    int precedence = GetPrecedence(source[i]);
                    while (operatorStack.Count > 0 && GetPrecedence(operatorStack.Peek()) >= precedence)
                    {
                        output += operatorStack.Pop() + " ";
                    }
                    operatorStack.Push(source[i]);
                }
                i++;
            }

            while (operatorStack.Count > 0)
            {
                output += operatorStack.Pop() + " ";
            }

            return output.Trim();
        }

        private string InfixToPrefix(string source)
        {
            string revsrc = string.Join("", source.Reverse());
            string output = InfixToPostfix(revsrc);
            return string.Join("", output.Reverse());
        }

        private int GetPrecedence(char oprtor)
        {
            switch (oprtor)
            {
                case '(':
                case ')': 
                    return 0;
                    break;
                case '+':
                case '-': 
                    return 1;
                    break;
                case '*':
                case '/': 
                    return 2;
                    break;
                case '^': 
                    return 3;
                    break;
                default: 
                    return -1;
                    break;
            }
        }

        private double EvaluatePostfix(string postfix)
        {
            Stack<double> stack = new Stack<double>();
            string[] tokens = postfix.Split(' ');

            foreach (string token in tokens)
            {
                if (double.TryParse(token, out double num))
                {
                    stack.Push(num);
                }
                else
                {
                    double operand2 = stack.Pop();
                    double operand1 = stack.Pop();
                    double result = ApplyOperator(token[0], operand1, operand2);
                    stack.Push(result);
                }
            }

            return stack.Pop();
        }

        private double ApplyOperator(char opr, double num1, double num2)
        {
            switch (opr)
            {
                case '+': 
                    return num1 + num2;
                case '-': 
                    return num1 - num2;
                case '*': 
                    return num1 * num2;
                case '/': 
                    return num1 / num2;
                case '^': 
                    return Math.Pow(num1, num2);
                default: 
                    throw new Exception("Invalid operator");
            }
        }
    }
}
